<?php


// ** MySQL settings ** //
/** The name of the database for WordPress */
define('DB_NAME', 'first_responders_network140407260118');

/** MySQL database username */
define('DB_USER', '561_media');

/** MySQL database password */
define('DB_PASSWORD', '561_media');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('AUTH_KEY',         'SZdpot4#)IhwUs3pU-2*YMmHv{HWp]f>|.HU.j5mBA+0|Dpkly3u50qd2qbI4&E2');
define('SECURE_AUTH_KEY',  'G*x*;gNHsF,+`QeM6q!!1%75i)=_2KpH[mAU /$Uix[hT3DHz ]Xv+mRsUpjX{J}');
define('LOGGED_IN_KEY',    'K{`]+24-*Mu_XFk{(B<Y~{]].dXm8QTN6I3sYL*v2b++?XVZ^T3hX^j_Y{zfB&Fz');
define('NONCE_KEY',        '+/#JYxJNC<`s=7U-+`V3},7T(8AyeW9/B)T#F>)|@sM%+@w1H$x(jK_9gBPZO{m6');
define('AUTH_SALT',        ')BUaZ0Uy>25)}*0hma_}ZPhvx%2~f>{a)9Ov@V:,K;?%-7iZ,3&?m-)Ol&yd/{_,');
define('SECURE_AUTH_SALT', '!W~B~|;o8Hv:kGyRpRx}`4oQWESpf}%H=1{GHe/.E;CP$-+t]V =]p2Gf2iq;EIx');
define('LOGGED_IN_SALT',   '[C/kePDp|SL$;|2t)=KqmiK?&BDrh)3&F3+KqQ ?}i|E5vJtg|9mhbIlYI2N{xQz');
define('NONCE_SALT',       'Z1x.~?z9%BNO7[-jX/8.o-i,1i9TU4B|6xTmBE.SXdnqLhIYW6;Q0>~G8z4)7Sq-');


$table_prefix = 'wp_';


define('ALLOW_UNFILTERED_UPLOADS', true);
define('WP_MEMORY_LIMIT','64M');
define('WP_DEBUG', false);
/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
define('FS_METHOD','direct');
